package beautyplan.mabnets.quickstore;
import java.io.Serializable;
public class commentdata implements  Serializable {
 public String id;
 public String prodid;
 public String user;
 public String comment;
}
