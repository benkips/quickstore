package beautyplan.mabnets.quickstore;
import  java.io.Serializable;
public class cate implements Serializable {
    public String id;
    public String category;
    public String total;
    public String icon;
}
