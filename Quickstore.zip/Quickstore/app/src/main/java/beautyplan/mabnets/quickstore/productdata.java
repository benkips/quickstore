package beautyplan.mabnets.quickstore;
import java.io.Serializable;
public class productdata implements Serializable {
    public String id;
    public String category;
    public String seller;
    public String product;
    public String photo;
    public String measure;
    public String cprice;
    public String ratings;
    public String description;
    public String time;
    public Integer price;

}
